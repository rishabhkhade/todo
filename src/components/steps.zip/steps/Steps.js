import React from "react";
import "./Steps.scss";
import img from "../../assets/tv/2114.jpg";

function Steps() {
  const data = [
    {
      step_image: img,
      step_name: "Heading",
      steps_contain:
        "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet neque, officia voluptatem sed ullam itaque doloribus ut a, saepe earum repellat reiciendis minima. Libero, distinctio.",
    },
    {
      step_image: img,
      step_name: "Heading",
      steps_contain:
        "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet neque, officia voluptatem sed ullam itaque doloribus ut a, saepe earum repellat reiciendis minima. Libero, distinctio.",
    },
    {
      step_image: img,
      step_name: "Heading",
      steps_contain:
        "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet neque, officia voluptatem sed ullam itaque doloribus ut a, saepe earum repellat reiciendis minima. Libero, distinctio.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet neque, officia voluptatem sed ullam itaque doloribus ut a, saepe earum repellat reiciendis minima. Libero, distinctio.",
    },
  ];

  return (
    <>
      <div class="parent step-parent">
        {data.map((item, index) => (
          <div class="container step-container">
            <div class="step-left">
              <img src={item.step_image} alt="" />
            </div>
            <div class="step-right">
              <h3>{item.step_name}</h3>
              <p>{item.steps_contain}</p>
            </div>

            <div class="steps-circle">
              <span className="steps-inner-circle"></span>
            </div>
          </div>
        ))}

        <div class="steps-middle-line"></div>
      </div>
    </>
  );
}

export default Steps;
